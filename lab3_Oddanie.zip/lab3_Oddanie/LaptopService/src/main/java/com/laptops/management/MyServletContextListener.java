package com.laptops.management;
import java.io.IOException;

import javax.servlet.*;

public class MyServletContextListener implements ServletContextListener, Servlet {

 public void contextInitialized(ServletContextEvent e) {
   System.out.println("Server started.");
   new Implementation().main(null);
 }

 public void contextDestroyed(ServletContextEvent e) {

 }

@Override
public void destroy() {
	// TODO Auto-generated method stub
	
}

@Override
public ServletConfig getServletConfig() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public String getServletInfo() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void init(ServletConfig arg0) throws ServletException {
	// TODO Auto-generated method stub
	
}

@Override
public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
	// TODO Auto-generated method stub
	
}
}