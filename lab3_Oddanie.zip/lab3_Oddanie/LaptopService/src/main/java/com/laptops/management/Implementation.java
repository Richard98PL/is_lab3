package com.laptops.management;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import javax.jws.WebService;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class Implementation implements IService{
	@Override
	public Integer getNumberOfLaptopsFromManufacturer(String manufacturer){
		return retrieveAllLaptops("manufacturer = '" + manufacturer + "'").length;
	}

	@Override
	public Integer getNumberOfLaptopsWithDesiredScreenSize(String screenSize){
		return retrieveAllLaptops("screen_size = '" + screenSize + "'").length;
	}
	public Boolean checkIfEmpty(String x) {
		return String.valueOf(x).trim().isBlank() || String.valueOf(x).equals("null") || x == null;
	}

	@Override
	public Laptop[] getLaptopsWithDesiredAttributes(String a, String b, String c, String d, String e){
		String where = "";
		if(!checkIfEmpty(a)) {
			where += "processor_physical_cores = '" + a + "' AND ";
		}
		if(!checkIfEmpty(b)) {
			where += "screen_touchscreen = '" + b + "' AND ";
		}
		if(!checkIfEmpty(c)) {
			where += "ram = '" + c + "' AND ";
		}
		if(!checkIfEmpty(d)) {
			where += "processor_name = '" + d + "' AND ";
		}
		if(!checkIfEmpty(e)) {
			where += "graphic_card_name = '" + e + "' AND";
		}
		
		where = where.length() > 5 ? where.substring(0, where.length()-4) : null;


		return retrieveAllLaptops(where);
	}
	
	@Override
	public Laptop[] getAllLaptops(){
		return retrieveAllLaptops(null);
	}
	
    static List < String > dbColumns = Arrays.asList(
            "manufacturer",
            "screen_size",
            "screen_type",
            "screen_touchscreen",
            "processor_name",
            "processor_physical_cores",
            "processor_clock_speed",
            "ram",
            "disc_storage",
            "disc_type",
            "graphic_card_name",
            "graphic_card_memory",
            "os",
            "disc_reader"
            ); 
    public static HashMap<String, String> fieldByColumn = new HashMap<String, String>();
	private static Connection con;
	
	private static Laptop[] retrieveAllLaptops(String where) {
		ArrayList<Laptop> laptops = new ArrayList<Laptop>();
    	String query = "SELECT * FROM jdbcdb.laptops;";
    	if(where != null && !where.equals("")) {
    		query = query.replace(";", "");
    		query = query + " WHERE " + where + ';';
    	}
    	System.out.println(query);
    	try {
			connectToDb();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
    	
    	try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			System.out.println("Executing query all...");

			while(rs.next()) {
				Laptop laptop = new Laptop();
				for(String columnName : dbColumns) {
					String value = (rs.getString(columnName));
					switch (columnName) {
					case "manufacturer":
						laptop.setManufacturer(value);
						break;
					case "screen_size":
						laptop.setScreenSize(value);
						break;
					case "screen_type":
						laptop.setScreenType(value);
						break;
					case "screen_touchscreen":
						laptop.setScreenTouchscreen(value);
						break;
					case "processor_name":
						laptop.setProcessorName(value);
						break;
					case "processor_physical_cores":
						try{
							laptop.setProcessorPhysicalCores(Integer.valueOf(value));
						}catch (Exception e) {
							
						}
						break;
					case "processor_clock_speed":
						laptop.setProcessorSpeed(value);
						break;
					case "ram":
						laptop.setRam(value);
						break;
					case "disc_storage":
						laptop.setDiscStorage(value);
						break;
					case "disc_type":
						laptop.setDiscType(value);
						break;
					case "graphic_card_memory":
						laptop.setGraphicCardMemory(value);
						break;
					case "os":
						laptop.setOs(value);
						break;
					case "disc_reader":
						laptop.setDiscReader(value);
						break;
					}
				}
				laptops.add(laptop);
			}
		
			st.close();
			con.close();
		} catch (SQLException e1) {
			System.out.println(e1.getMessage());
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    	Laptop[] returnArray = new Laptop[laptops.size()];
    	Integer i = 0;
    	for(Laptop laptop : laptops) {
    		returnArray[i] = laptop;
    		i++;
    	}
    	return returnArray;
		
	}
	
	
	private static void connectToDb() throws SQLException {
		try {
			System.out.println("Loading driver...");
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded.");
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcdb", "root", "root");
				System.out.println("connection checking.");
				System.out.println(con);
			} catch (SQLException e) {
				System.out.println(e.getMessage());
				System.out.println("SQLException");
			}
		} catch (Exception e1) {
			System.out.println("Class not found");
			System.out.println(e1.getMessage());
		}
	}

}
